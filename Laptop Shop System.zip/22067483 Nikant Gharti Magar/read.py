def readfile():
    with open("laptop.txt",'r') as file:
        laptopID = 1
        my_dict = {}
        for line in file:
            line = line.replace("\n","")
            my_dict[laptopID] = line.split(",")
            laptopID += 1
    #print(my_dict)
    return my_dict