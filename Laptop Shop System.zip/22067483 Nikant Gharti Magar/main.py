
from datetime import datetime
from read import *
from operations import *
from write import *


my_dict = readfile()
print("\n")
print("=====================================================================================")
print("\t \t Welcome to Babu Tyam's laptop store")
print("=====================================================================================")
print("\t \t Address: Kritipur Contact: 9806810491")
print("=====================================================================================")
print("\n")

continueLoop = True 
while continueLoop == True:
    print("\n")
    print("Press 1 to buy from manufacturer")
    print("Press 2 to sell to customer")
    print("Press 3 to exit")
    userinput = 0
    try:
        userinput = int(input("Enter 1,2 or 3: "))
    except:
        print("Enter the specified prompt")
        continue
    
    
        
    if userinput == 1:
        today_date_and_time = datetime.now()
        name, number, user_purchased_laptops, vat_amount, final_total = buy(my_dict)
        write_buy(name, number, user_purchased_laptops, vat_amount, final_total)
            
    elif userinput == 2:
        
        name, number, user_purchased_laptops,grand_total = sell(my_dict)
        write_sell(name, number, user_purchased_laptops,grand_total)
    elif userinput == 3:
        continueLoop = False
        print("Thank You for visiting")
    else:
        print("Enter correct option")
