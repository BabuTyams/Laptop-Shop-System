from read import *
from datetime import datetime
def buy(my_dict):  
    print("Thank you for buying from manufacturer")
    print("=====================================================================================")
    print("We will need your name and phone number")
    name = input("Enter your name: ")
    number = input("Enter your number: ")
    print("=====================================================================================")

    print("S.N. \t Name \t\t Brand \t\t Price Quantity Processor \t Graphic Card")
    print("=====================================================================================")
    a = 1
    with open("laptop.txt",'r') as file:
        for line in file:
            print(a,"\t" + line.replace(",","\t"))
            a +=1
        print("=====================================================================================")

        print("\n")
        valid_id = 0
        try:
            valid_id = int(input("Please provide the ID of the laptop you want to buy: "))
        except:
            print("Enter a number!")
        while valid_id<=0 or valid_id>len(my_dict):
            print("Please provide a valid laptop ID!")
            print("\n")
            try:
                valid_id = int(input("Please provide the ID of the laptop you want to buy: "))
            except:
                print("Enter a number")

        valid_quantity = 0
        try:
            valid_quantity = int(input("Please provide the quantity of the laptop you want to buy: "))
        except:
            print("Please provide the valid input.")
        get_quantity = my_dict[valid_id][3]
        while valid_quantity<=0:
            print("\n")
            try:
                valid_quantity = int(input("Please provide the quantity of the laptop you want to buy: "))
            except:
                print("Please provide the valid input.")

        my_dict[valid_id][3] = int(my_dict[valid_id][3]) + int(valid_quantity)
        with open("laptop.txt","w") as file:
            for values in my_dict.values():
                file.write(str(values[0])+ "," + str(values[1]) + "," + str(values[2])+ "," + str(values[3])+ "," + str(values[4])+ "," + str(values[5]))
                file.write("\n")

        #Purchasing from manufacturer
        name_of_product = my_dict[valid_id][0]
        quantity_selected_by_user = valid_quantity
        unit_price = my_dict[valid_id][2]
        price_of_selected_item = my_dict[valid_id][2].replace("$",'')
        total_price = int(price_of_selected_item)*int(quantity_selected_by_user)

        user_purchased_laptops = []
        user_purchased_laptops.append([name_of_product, quantity_selected_by_user, unit_price, total_price])

        vat_amount = total_price * 0.13
        final_total = total_price + vat_amount

        buy_loop = True
    while buy_loop == True:
        buy = input("Do you want to buy more laptops?(y/n):")
        if buy == "y" or buy == "Y":

            #Valid ID
            valid_id = 0
            try:
                valid_id = int(input("Please Provide the ID of the laptop you want to buy:"))
                print("\n")
            except:
                print("Enter a number")
            
            while valid_id <= 0 or valid_id > len(my_dict):
                print("Please provide a valid Laptop ID !!")
                print("\n")
            
                try:
                    valid_id = int(input("Please Provide the ID of the laptop you want to buy:"))
                    print("\n")
                except:
                    print("Enter a number")

            user_quantity = 0
            try:
                user_quantity = int(input("Please Provide the number of quantity of the Laptop you want to buy:"))
                print("\n")
            except:
                print("Please provide the valid input")

            while valid_quantity<=0:
                print("\n")
            try:
                valid_quantity = int(input("Please provide the quantity of the laptop you want to buy: "))
            except:
                print("please provide the valid input")
            

           
            #Valid Quantity

            my_dict = readfile()
            get_quantity = my_dict[valid_id][3]
            while user_quantity <= 0 or user_quantity > int(get_quantity):
                print("Dear Admin, the quantity you looking for is not available in our shop. Please look again in the Laptop screen")
                print("\n")

                try:
                    user_quantity = int(input("Please Provide the number of quantity of the Laptop you want to buy: "))
                    print("\n")
                except:
                    print("Please provide the valid input.")

            

            #Update the text file

            my_dict[valid_id][3] = int(my_dict[valid_id][3]) + int(user_quantity)

            file = open("Laptop.txt","w")

            for values in my_dict.values():
                file.write(str(values[0])+"," +str(values[1])+"," +str(values[2])+"," +str(values[3])+"," +str(values[4])+"," +str(values[5]))
                file.write("\n")
            file.close()

            #Purchasing from manufacturer

            product_name = my_dict[valid_id][0]
            brand_name = my_dict[valid_id][1]
            quantity_of_user = user_quantity
            price_of_unit = my_dict[valid_id][2].replace("$","")
            final_price = int(price_of_unit)*int(quantity_of_user)

            final_total = final_total + final_price
            VAT = 0.13 * final_total
            total_with_vat = VAT + final_total
           
            user_purchased_laptops.append([product_name, brand_name, quantity_of_user, price_of_unit, final_price])
            
        else:
            buy_loop = False

        today_date_and_time = datetime.now()
        print("\n")
        print("\t \t \t \t laptop shop bill ")
        print("\n")
        print("\t \t kamalpokhari, kathmandu | phone no: 9841324552")
        print("\n")
        print("----------------------------------------------------------------------")
        print("Laptop details are:")
        print("----------------------------------------------------------------------")
        print("Name of the Customers: " + str(name))
        print("Contact number: " + str(number))
        print("Date and time of purchase: " + str(today_date_and_time))
        print("----------------------------------------------------------------------")
        print("\n")
        print("Purchase Detail are:")
        print("----------------------------------------------------------------------")
        print("Item Name \t\t Unit Price \t\t\t Total")
        print("----------------------------------------------------------------------")
        for i in user_purchased_laptops:
            print(i[0],"\t\t\t",i[1],"\t\t\t",i[2],"\t\t\t","$",i[3])
        print("----------------------------------------------------------------------")
        print("Vat amount: "+ str(vat_amount))
        print("Grand total: "+str(final_total))

    return name, number, user_purchased_laptops, vat_amount, final_total

def sell(my_dict):
    print("Thank you for selling to customer")
    
    print("=====================================================================================")
    print("We will need your name and phone number")
    name = input("Enter your name: ")
    number = input("Enter your number: ")
    print("=====================================================================================")

    print("S.N. \t Name \t\t Brand \t\t Price Quantity Processor \t Graphic Card")
    print("=====================================================================================")
    a = 1
    with open("laptop.txt",'r') as file:
        for line in file:
            print(a,"\t" + line.replace(",","\t"))
            a +=1
        print("=====================================================================================")

        print("\n")

        valid_id = 0
        try:
            valid_id = int(input("Please provide the ID of the laptop you want to buy: "))
        except:
            print("Please provide the valid input.")

        while valid_id<=0 or valid_id>len(my_dict):
            print("Please provide a valid laptop ID!")
            print("\n")
            
            try:
                valid_id = int(input("Please provide the ID of the laptop you want to buy: "))
            except:
                    print("Please provide the valid input.")


        valid_quantity = 0
        try:
            valid_quantity = int(input("Please provide the quantity of the laptop you want to buy: "))
            print("\n")
        except:
            print("Please provide the valid input.")
        

        get_quantity = my_dict[valid_id][3]
        while valid_quantity<=0 or valid_quantity > int(get_quantity):
            print("Dear Admin, we do not have enough laptop, please retry!")
            print("\n")

            try:
                valid_quantity = int(input("Please provide the quantity of the laptop you want to buy: "))
                print("\n")
            except:
                print("Please provide the valid input.")

        my_dict[valid_id][3] = int(my_dict[valid_id][3]) - int(valid_quantity)
        with open("laptop.txt","w") as file:
            for values in my_dict.values():
                file.write(str(values[0])+ "," + str(values[1]) + "," + str(values[2])+ "," + str(values[3])+ "," + str(values[4])+ "," + str(values[5]))
                file.write("\n")

        # Getting user purchased items
        name_of_product = my_dict[valid_id][0]
        quantity_selected_by_user = valid_quantity
        unit_price = my_dict[valid_id][2]
        price_of_selected_item = my_dict[valid_id][2].replace("$",'')
        total_price = int(price_of_selected_item)*int(quantity_selected_by_user)

        user_purchased_laptops = []
        user_purchased_laptops.append([name_of_product, quantity_selected_by_user, unit_price, total_price])

        shipping_cost = input("Dear user do you want your laptop to be shipped?(Y/N)").upper()

        if shipping_cost == "Y":
            total = 0
            shipping_cost = 500
            for i in user_purchased_laptops:
                total += int(i[3])
            grand_total = total + shipping_cost

        sale_loop = True
    while sale_loop == True:
        continue_sale = input("Do you want to buy more laptops? (y/n) ").lower()
        if continue_sale == "y" or continue_sale == "yes":
            valid_id = int(input("Please Provide the ID of the product you want to sell:"))
            print("\n")

            #Valid ID

            valid_id = 0
            try:
                valid_id = int(input("Please Provide the ID of the laptop you want to sell:"))
            except:
                print("Please provide the valid input")
            while valid_id <= 0 or valid_id > len(readfile()):
                print("Please provide a valid Laptop ID !!")
                try:
                    valid_id = int(input("Please Provide the ID of the laptop you want to sell:"))
                except:
                    print("Please provide the valid input")
            user_quantity =0
            try:   
                user_quantity = int(input("Please Provide the number of quantity of the laptop you want to sell:"))
            except:
                print("Please provide the valid input.")
            while valid_quantity <= 0 or valid_id > len(readfile()):
                print("please provide the valid input")
                try:
                    valid_quantity = int(input("Please Provide the ID of the laptop you want to sell:"))
                except:
                    print("please provide the valid input")
            #Valid Quantity

            my_dict = readfile()
            get_quantity = my_dict[valid_id][3]
            while user_quantity <= 0 or user_quantity > int(get_quantity):
                print("Dear Admin, the quantity you looking for is not available in our shop. Please look again in the Laptop screen")
                print("\n")

                try:
                    user_quantity = int(input("Please Provide the number of quantity of the Laptop you want to sell: "))
                    print("\n")
                except:
                    print("Please provide the valid input.")

            #Update the text file

            my_dict[valid_id][3] = int(my_dict[valid_id][3]) - int(user_quantity)

            file = open("Laptop.txt","w")

            for values in my_dict.values():
                file.write(str(values[0])+"," +str(values[1])+"," +str(values[2])+"," +str(values[3])+"," +str(values[4])+"," +str(values[5]))
                file.write("\n")
            file.close()

            #getting user purchased items

            product_name = my_dict[valid_id][0]
            brand_name = my_dict[valid_id][1]
            quantity_of_user = user_quantity
            #price_of_unit = my_dict[valid_id][2]
            price_of_item = my_dict[valid_id][2].replace("$",'')
            final_price = int(price_of_item)*int(quantity_of_user)
            final_total = 0

            user_purchased_laptops.append([product_name, brand_name, quantity_of_user, price_of_item, final_price])
            final_total = final_total + final_price
        else:
            sale_loop = False

        today_date_and_time = datetime.now()
        print("\n")
        print("\t \t \t \t laptop shop bill ")
        print("\n")
        print("\t \t kamalpokhari, kathmandu | phone no: 9841324552")
        print("\n")
        print("----------------------------------------------------------------------")
        print("Laptop details are:")
        print("----------------------------------------------------------------------")
        print("Name of the Customers: " + str(name))
        print("Contact number: " + str(number))
        print("Date and time of purchase: " + str(today_date_and_time))
        print("----------------------------------------------------------------------")
        print("\n")
        print("Purchase Detail are:")
        print("----------------------------------------------------------------------")
        print("Item Name \t\t Quantity \t\t Unit Price \t\t\t Total")
        print("----------------------------------------------------------------------")
        for i in user_purchased_laptops:
            print(i[0],"\t\t",i[1],"\t\t",i[2],"\t\t","$",i[3])
        print("----------------------------------------------------------------------")
        if shipping_cost:
            print("Your Shipping Cost is: ", shipping_cost)
            print("Grand Total: $"+str(grand_total))
            print("Note: Shipping cost is added to the grand total")
        else:
            print("Grand Total: $"+str(grand_total))
    return name, number, user_purchased_laptops,grand_total
